package editor;

import graphics.Line;
import java.awt.BorderLayout;
import graphics.Canvas;

import graphics.Oval;
import graphics.Point;
import graphics.Rect;
import graphics.Shape;
import graphics.Shapes;
import graphics.ShapesFactory;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author trran
 */
public class Editor extends JFrame implements MouseListener, MouseMotionListener {

    private JLabel statusLabel;
    private Canvas canvas;
    private Shape currentShape;
    private Shapes currentShapeType;
    private Color currentShapeLineColor = Color.black;
    private Color currentShapeFillColor = Color.black;
    private boolean currentShapeFilled = true;
    private final int XOFF = 8;
    private final int YOFF = 64;

    public Editor() {
        super("Collage Editor");
        init();
    }

    private void init() {

        setLayout(new BorderLayout());
        canvas = new Canvas();
        canvas.setBackground(Color.white);
        add(canvas, BorderLayout.CENTER);
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());
        add(controlPanel, BorderLayout.NORTH);
        currentShapeType = Shapes.LINE;
        JComboBox shapesBox = new JComboBox(Shapes.values());
        shapesBox.addActionListener((ActionEvent) -> {
                currentShapeType = (Shapes)shapesBox.getSelectedItem();
        });
        controlPanel.add(shapesBox);
        JButton colorButton = new JButton("Line Color");
        colorButton.addActionListener((ActionEvent e) -> {
            Color c = JColorChooser.showDialog(this, "Line Color", Color.black);
            currentShapeLineColor = c;
            colorButton.setForeground(c);
        });
        controlPanel.add(colorButton);
        JButton filledButton = new JButton("Fill Color");
        filledButton.addActionListener((ActionEvent e)->{
            Color c = JColorChooser.showDialog(this, "Line Color", Color.black);
            currentShapeFillColor = c;
            filledButton.setForeground(c);
    });
        controlPanel.add(filledButton);

        JCheckBox filledCheckBox = new JCheckBox("Filled");
        controlPanel.add(filledCheckBox);

        JButton clearButton = new JButton("Clear");
        controlPanel.add(clearButton);
        clearButton.addActionListener((ActionEvent e) -> canvas.clear());
        JButton undoButton = new JButton("Undo");
        controlPanel.add(undoButton);
        undoButton.addActionListener((ActionEvent e) -> canvas.undo());
        JPanel statusPanel = new JPanel();
        add(statusPanel, BorderLayout.SOUTH);
        statusLabel = new JLabel("(000,000");
        statusPanel.add(statusLabel);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Editor editor = new Editor();
        editor.setSize(800, 800);
        editor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        editor.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        currentShape = ShapesFactory.create(
                currentShapeType, e.getX()-XOFF, e.getY()-YOFF, e.getX()-XOFF, e.getY()-YOFF,    //e to me
                currentShapeLineColor, currentShapeFilled, currentShapeFillColor);
        canvas.add(currentShape);
        canvas.repaint();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        currentShape = null;
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (currentShape != null) {
            currentShape.setP2(new Point(e.getX()-XOFF, e.getY()-YOFF));                 
        }
        canvas.repaint(); 
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        statusLabel.setText(String.format("(%03d,%03d)", e.getX()-XOFF,e.getY()-YOFF));    
    }

}
